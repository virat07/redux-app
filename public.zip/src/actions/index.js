export function selectBook(id){
	return {
		type: 'BOOK_SELECTED',
        payload: { id}
	}
}