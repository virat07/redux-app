export default function(){
	return [
	{
		"Category": {
		  "cult": "Cultural", 
		  "roman": "Romantic", 
		  "hor": "Horror", 
		  "fant": "Fantasy", 
		  "prog": "Programming", 
		  "trvl": "Travel", 
		  "comd": "Comedy", 
		  "poet": "Poetry"
		}, 
		"Description": {
		  "cult": {
			"book1": {
			  "category": "Cultural", 
			  "name": "A thousand splendid suns", 
			  "description": "Situation faced after marraige"
			}, 
			"book2": {
			  "category": "Cultural", 
			  "name": "The kite Runner", 
			  "description": "Fight with kites"
			}, 
			"book3": {
			  "category": "Cultural", 
			  "name": "Memories of Geisha", 
			  "description": "Story before and after World war 2"
			}
		  }, 
		  "roman": {
			"book1": {
			  "category": "Romantic", 
			  "name": "Dark Lover", 
			  "description": "True love never dies"
			}, 
			"book2": {
			  "category": "Romantic", 
			  "name": "Lord Perfect", 
			  "description": "Man with Perfect skills"
			}, 
			"book3": {
			  "category": "Romantic", 
			  "name": "R is For Rebel", 
			  "description": "My gem of life"
			}, 
			"book4": {
			  "category": "Romantic", 
			  "name": "Shanna", 
			  "description": "Secret love story"
			}
		  }, 
		  "hor": {
			"book1": {
			  "category": "Horror", 
			  "name": "The Haunting Of a Hill House", 
			  "description": "A dark secret of a hill"
			}, 
			"book2": {
			  "category": "Horror", 
			  "name": "House of leaves", 
			  "description": "Black magic leaves"
			}, 
			"book3": {
			  "category": "Horror", 
			  "name": "The Shining", 
			  "description": "Darkest night ever"
			}
		  }, 
		  "fant": {
			"book1": {
			  "category": "Fantasy", 
			  "name": "The black company", 
			  "description": "The last fantasy"
			}, 
			"book2": {
			  "category": "Fantasy", 
			  "name": "The Broken Empire", 
			  "description": "My heart's fantasy"
			}
		  }, 
		  "prog": {
			"book1": {
			  "category": "Programming", 
			  "name": "Java", 
			  "description": "Pure java programming book"
			}, 
			"book2": {
			  "category": "Programming", 
			  "name": "C", 
			  "description": "Pure C programming book"
			}, 
			"book3": {
			  "category": "Programming", 
			  "name": "C++", 
			  "description": "Pure c++ programming book"
			}, 
			"book4": {
			  "category": "Programming", 
			  "name": "Javascript", 
			  "description": "Pure javascript programming book"
			}
		  }, 
		  "trvl": {
			"book1": {
			  "category": "Travel", 
			  "name": "The Alchemist", 
			  "description": "Roads full of emergencies"
			}, 
			"book2": {
			  "category": "Travel", 
			  "name": "On the road", 
			  "description": "long route "
			}, 
			"book3": {
			  "category": "Travel", 
			  "name": "Love with the chance of drowning", 
			  "description": "Travel and love"
			}, 
			"book4": {
			  "category": "Travel", 
			  "name": "Unlikely Destinations", 
			  "description": "Path which was never decided"
			}, 
			"book5": {
			  "category": "Travel", 
			  "name": "The lost city of Z", 
			  "description": "The route I never followed"
			}
		  }, 
		  "comd": {
			"book1": {
			  "category": "Comedy", 
			  "name": "Cold comfort farm", 
			  "description": "story of a farm"
			}, 
			"book2": {
			  "category": "Comedy", 
			  "name": "The sellout", 
			  "description": "selling machine"
			}
		  }, 
		  "poet": {
			"book1": {
			  "category": "Poetry", 
			  "name": "Things fall apart", 
			  "description": "Lack of decision making"
			}, 
			"book2": {
			  "category": "Poetry", 
			  "name": "Leaves of Grass", 
			  "description": "It's all about nature"
			}, 
			"book3": {
			  "category": "Poetry", 
			  "name": "Divine Comedy", 
			  "description": "The greatest works of world literature"
			}, 
			"book4": {
			  "category": "Poetry", 
			  "name": "The collected Poems", 
			  "description": "A book of deep thoughts"
			}, 
			"book5": {
			  "category": "Poetry", 
			  "name": "The waste land", 
			  "description": "Heart broken truth of the earth"
			}
		  }
		}
	  }
]
}