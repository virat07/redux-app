import React, { Component } from 'react';
import './App.css';
import BookList from './Component/book-list';
import BookDetail from './Component/book-detail';

class App extends Component {
  render() {
    return (
      <div className="App">
        <div><BookList/>
      <BookDetail/></div>
      </div>
    );
  }
}

export default App;
