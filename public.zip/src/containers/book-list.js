import React, {Component} from 'react';
import {connect} from 'react-redux';
import {selectBook} from '../actions/index';
import {bindActionCreators} from 'redux';

class BookList extends Component{
render(){
	return (
		<div className='left-container'>
		<ul className='List' id="List" >
		{this.props.books[0].Category ? Object.keys(this.props.books[0].Category).map((key) => {
			return <li key={key} id={key}
			onClick={()=> this.props.selectBook(key) }
			>{this.props.books[0].Category[key]}
			</li>
		}) : ''}
	</ul>
	</div>
	)
}
}

function mapStateToProps(state){
	return{
		books:state.books
	};

}


function mapDispatchToProps(dispatch){
	return bindActionCreators({selectBook: selectBook}, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(BookList);