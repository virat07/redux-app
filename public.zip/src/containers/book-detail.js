import React, { Component } from 'react';
import { connect } from 'react-redux';
import BookDisplay from './book-display';
import './style.css';
class BookDetail extends Component {

	render() {
		if (!this.props.book) {
			return <div className='right-container' id='Default-statement'>select a book to get started.</div>;
		}
		let detailed = this.props.book.id;
		
		let example = this.props.books[0].Description;
		let seletedCategoryList = example[detailed];
	
		let bookKeys = Object.keys(example[detailed])

		bookKeys.forEach(book => {
			console.log(JSON.stringify(seletedCategoryList[book]));
		});

		return (


			<div className='parent-container'>
				<div className='right-container'>
					<div className="column_1" id="data">
						<h2>Name</h2>
					</div>
					<div className="column_1" id="data">
						<h2>Description</h2>
					</div>
					<div className="column_1" id="data">
						<h2>Category</h2>
					</div>

						{bookKeys.map((book, i) => <BookDisplay {...seletedCategoryList[book]} key={i} id={i} />)}
				</div>
			</div>

		);
	}
}

function mapStateToProps(state) {
	return {
		book: state.activeBook,
		books: state.books
	};

}

export default connect(mapStateToProps)(BookDetail);