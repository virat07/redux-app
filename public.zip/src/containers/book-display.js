import React, {Component} from 'react';
const BookDisplay = (props) => {
   return(
    <div className='row' key={props.id}>
  <div className='column'>
        {props.name}
        </div>
  <div className='column'>
        {props.description}
        </div>
  <div className='column'>
        {props.category}
        </div>
        </div>
   )
}
export default BookDisplay;